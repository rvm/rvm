# 1.19.1

## update autolibs
git cherry-pick fdb1bd8

## improve freebsd support
git cherry-pick 3187d90

## https://github.com/wayneeseguin/rvm/issues/1682
git cherry-pick bc9149f
git cherry-pick af856f5

## https://github.com/wayneeseguin/rvm/issues/1724
git cherry-pick 9ed79bf
git cherry-pick a02beac

## https://github.com/wayneeseguin/rvm/pull/1725
git cherry-pick 390f66b -m 1

## https://github.com/wayneeseguin/rvm/pull/1727
git cherry-pick 6a342fc -m 1

## https://github.com/wayneeseguin/rvm/pull/1733
git cherry-pick b133ee2 -m 1

## https://github.com/wayneeseguin/rvm/issues/1736
git cherry-pick d9642c3

## https://github.com/wayneeseguin/rvm/issues/1741
git cherry-pick 241b3cc

## https://github.com/wayneeseguin/rvm/issues/1722
git cherry-pick 5e0bb5e
git cherry-pick 9d96bac

## https://github.com/wayneeseguin/rvm/issues/1680
git cherry-pick 77a88fa
git cherry-pick 3c53e19
git cherry-pick 071b8ba

## https://github.com/wayneeseguin/rvm/issues/1743
git cherry-pick 31cb203

## https://github.com/wayneeseguin/rvm/issues/1720 / 1724
git cherry-pick 903e4e0d
git cherry-pick ba05607f
git cherry-pick de567325

## fix compiler detections
git cherry-pick e08e8f8

## https://github.com/wayneeseguin/rvm/issues/1746
git cherry-pick bdb12a2
