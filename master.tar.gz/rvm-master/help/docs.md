
∴ rvm docs {generate,generate-ri,generate-rdoc}

Generates ri and / or rdoc documentation for the current ruby.

If you have the hanna gem installed, rdoc generation should automatically use it.
Alternatively, you can pass the --docs flag to automatically call 'rvm docs generate'
as part of the install process.

Examples:

  ∴ rvm docs generate

Generates both ri and rdoc documentation for the current ruby.

  ∴ rvm docs generate-ri

Generates only ri documentation for the current ruby.

  ∴ rvm docs generate-rdoc

Generates only rdoc documentation for the current ruby.
