∴ rvm rvmrc warning [check|ignore|reset] [<path>|all.rvmrcs|allGemfiles]
∴ rvm rvmrc warning [help|list]

Manage warnings for .rvmrc / Gemfile
